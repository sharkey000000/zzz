Sharkey 서버 통합 리소스팩
==============================

대상: Minecraft Java 26.2 / Resource Pack format 88

포함 기능:
1. 물 재화 전용 물방울 텍스처
   - PublicBukkitValues -> watercurrency:water = 1 인 물 재화에 적용
   - 일반 물 양동이는 기존 텍스처 유지

2. 프리즈머린 벽돌 투명화
   - prismarine_bricks.png를 완전 투명으로 변경한 리소스팩 내용 포함
   - 주의: 현재 팩 구조상 '프리즈머린 벽돌' 텍스처 자체를 변경하므로,
     일반 프리즈머린 벽돌에도 영향을 줄 수 있습니다.
   - 블록의 충돌/히트박스/행동은 변경하지 않습니다.

설치:
- 서버 강제 리소스팩으로 사용하려면 이 ZIP 파일을 그대로 웹에 올리고
  server.properties의 resource-pack에 직접 다운로드 주소를 넣으세요.
- require-resource-pack=true 를 사용하면 적용을 거부한 플레이어의 접속을 막을 수 있습니다.
